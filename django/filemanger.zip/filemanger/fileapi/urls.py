from django.urls import path
from .views import signup,signin,home,signout

urlpatterns = [
    path('',home,name="Home"),
    path('signin/',signin,name="signin"),
    path('signup/',signup,name="signup"),
    path('signout/',signout,name="sigout"),
]