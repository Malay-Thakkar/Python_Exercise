from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import signupForm
from .models import signup as signupModel
from datetime import datetime

# Create your views here.
def signup(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        signup_entry = signupModel(name=name,email=email,password=password,date=datetime.now())
        signup_entry.save()
        
        user = User.objects.filter(username=username) 
        if user.exists():
            messages.info(request, "Username already taken!")
            return redirect('/signup/')
        user = User.objects.create_user(
            first_name=name,
            username=username,
            email=email,
        )
        user.set_password(password)
        messages.info(request, "Account created Successfully!")
        return redirect('home')
    return render(request,'signup.html')

def signin(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(email=email,password=password)
        if user is not None:
            login(request,user)
            return render(request, 'authentication/index.html', {'user': user})
        else:
            messages.error(request,'Bad credentials!')  
            
    return render(request,'signin.html')

def signout(request):
    logout(request)
    messages.success(request,"Logout sussessfully!")
    return redirect('signin')
def home(request):
    return render(request,'index.html')
    # return HttpResponse("hello")