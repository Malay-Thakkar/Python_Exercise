from django.db import models
from django.utils import timezone

# Create your models here.
class signup(models.Model):
    name=models.CharField(max_length=120)
    username=models.CharField(max_length=120,default="default_username")
    email=models.EmailField(max_length=120)
    password = models.CharField(max_length=20)
    date = models.DateField(default=timezone.now)    
